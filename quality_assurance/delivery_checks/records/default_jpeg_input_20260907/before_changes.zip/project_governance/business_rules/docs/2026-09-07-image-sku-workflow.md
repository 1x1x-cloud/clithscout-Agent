# 原商品主图到差评 SKU 核对

用户于 2026-09-07 指定实现：原商品主图 → 图片找相似款 → 按差评核对尺码、面料和具体 SKU。本文定义这条流程的输入与核对规则；供货门槛继续引用 [V1 方案](2026-09-06-clothing-demand-agent-v1-design.md)，执行状态见 [TASK_STATE.md](../../project_state/docs/TASK_STATE.md)。

## 流程与边界

1. 从当前需求卡引用的评价读取 `productMainImage`，保留原商品 ID、评价 ID、所购 SKU、来源 URL 和采集时间。仅接收 HTTP(S) 主图 URL；评价晒图和头像不作主图替代。同商品出现不同主图时记录冲突，缺失或无效时记录待补资料。
2. 按原商品和主图合并需求，调用项目内 1688 `image_search --image`。查询上限沿用本轮配置；超过上限的需求保留待办。图片模式不自动退回文字搜索；接口失败停止后续查询。文字模式和旧快照回放继续可用。
3. 保存完整搜索返回、来源时间和候选商品/SKU。图片只代表平台召回的相似线索；不据此确认同款、成分、厚薄、尺寸或痛点解决。原图保存 URL 引用，未下载归档的图片不声称已保全像素内容。
4. 逐条支持评价关联原 SKU、目标条件、候选 SKU 资料。分别核对 SKU 绑定、目标尺寸与面料成分，输出 `met / conflict / unknown` 及依据。缺项、不同测量口径或多义目标保持待确认。目标来源需明确；不会把“太大”转成 S 码，也不会把“扎皮肤”转成纯棉要求。
5. 即使资料对照满足已提供的规格，也不证明实际穿着问题解决；`demand_satisfied` 保持待实物复核，供货和现货测品门槛沿用 V1。搜索标签、库存展示和规格资料不能直接升级供货状态。

## SKU 资料输入（JSON，schema_version 为 1）

顶层包含 `sku_records` 和 `review_targets` 数组。记录为用户或资料提供方的陈述；程序校验引用格式和身份一致性，不自动核实引用网页的真实性。

- `sku_records`：`platform`（`tiktok` 或 `1688`）、字符串 `product_id`、字符串 `sku_id`、`source_ref`、含时区的 `checked_at`；可选 `size_label`、`measurements`、`materials`、`composition_complete`。平台/商品/SKU 三元组唯一。
- `review_targets`：字符串 `review_id`、`source_product_id`、`source_sku_id`、现有规则中的 `issue`、`source_ref`、含时区的 `checked_at`；可选 `measurements` 和 `materials`。同一评价/问题只接受一份目标，且须与本轮证据中的原商品及 SKU 对齐。
- SKU 的 `measurements` 每项为 `name`、`value`、`unit`、`basis`；目标的每项为 `name`、`min`、`max`、`unit`、`basis`。`basis` 取 `garment_length`、`garment_flat_width`、`garment_circumference` 或 `body_circumference`；只在名称与口径一致时比较。单位支持 `cm` 与 `inch`，1 inch = 2.54 cm；范围含两端。身体尺寸不能直接当成成衣尺寸。
- SKU 的 `materials` 为材料名称到百分比的映射，例如 `{"cotton": 100}`；`composition_complete: true` 时合计须为 100。目标 `materials` 为名称到最低百分比的映射。名称仅忽略首尾空白和大小写，不自动把材料同义词或不同语言视为同一成分。
- 目标对照需同时有对应原 SKU 和候选 SKU 的资料。所需测量项缺失时为未知；明确超出范围为冲突。材料缺失且成分未完整列出时为未知，完整成分中无目标材料则按 0% 比较。触感、透视、缩水、垂坠等性能仍需相应实物测试。
- `source_ref` 指向资料页或可复查的本地资料；`checked_at` 表示该资料的核对时间。回放使用归档的资料输入和原搜索时间，不刷新为当前库存或报价。
- 新资料复核通过独立的 `--recheck-run` 入口，必须提供 `--sku-evidence`；复用已归档的图片搜索返回，保留原搜索时间，另存资料和核对结果。原样回放 `--replay-run` 仍使用快照内资料，拒绝替换输入。

## 最小验收

- 主图正确来源、原商品不串联、重复需求合并、缺图/冲突图阻止该项搜索、查询上限生效。
- 图片命令通过参数列表调用，失败保留证据与待办；不启动新 Actor。
- 尺码标签不能代替尺寸；不同 SKU、测量口径和材料缺失不会被判为满足。
- 用合成资料验证明确目标的满足/冲突/未知分支、cm/inch 换算、重复或无效资料拒绝。
- 图片运行可离线回放，输入及返回可追溯；旧文字快照回放保持原判断；现货候选不会被自动批准。
