param([switch]$Live, [string]$Reviews, [string]$ReplayRun, [switch]$Test, [switch]$VerifyMigration)
$ErrorActionPreference = 'Stop'
$projectRoot = (Get-Item -LiteralPath $PSScriptRoot).Parent.Parent.Parent.FullName
$pythonExe = Join-Path $projectRoot 'runtime_support/python_environment/venv/Scripts/python.exe'
$launchScript = Join-Path $projectRoot 'workflow_execution/launcher/scripts/launch.py'
if (-not (Test-Path -LiteralPath $pythonExe)) { throw 'Project Python environment is missing; see START_HERE.md.' }
if (($Live -and ($Reviews -or $ReplayRun)) -or ($Reviews -and $ReplayRun)) { throw 'Choose a single input mode.' }
$agentArgs = @('-B', $launchScript)
if ($Live) { $agentArgs += @('--live-read', '--live-search') }
if ($Reviews) { $agentArgs += @('--reviews', $Reviews) }
if ($ReplayRun) { $agentArgs += @('--replay-run', $ReplayRun) }
if ($Test) { $agentArgs += '--test' }
if ($VerifyMigration) { $agentArgs += '--verify-migration' }
$env:PYTHONIOENCODING = 'utf-8'
Push-Location -LiteralPath $projectRoot
try { & $pythonExe @agentArgs; $agentExit = $LASTEXITCODE } finally { Pop-Location }
exit $agentExit
