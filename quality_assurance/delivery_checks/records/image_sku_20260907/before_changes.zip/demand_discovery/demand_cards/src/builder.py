"""ClothScout module; migrated without changing business thresholds."""
from collections import defaultdict
from runtime_support.text_identity.src.identity import digest
from demand_discovery.pain_classification.src.rules import ISSUES

def build_cards(evidence, config):
    groups = defaultdict(list)
    for e in evidence:
        if e["duplicate_of"] or e["flags"]:
            continue
        scope = "current" if e["in_window"] and e["market_as_reported"] == config["market"] else "historical_or_other_market"
        for hit in e["extractions"]:
            groups[(scope, e["product_id"], hit["issue"])].append(e)
    cards = []
    for (scope, pid, issue), support in groups.items():
        categories = {e["category"] for e in support}
        category = next(iter(categories)) if len(categories) == 1 else None
        counter = [e["evidence_id"] for e in evidence if e["product_id"] == pid
                   and e["kind"] == "positive_fit" and issue in ("too_long", "too_short", "too_big", "too_small", "fit_unspecified")
                   and e["in_window"] == support[0]["in_window"] and e["market_as_reported"] == config["market"]
                   and not e["flags"] and not e["duplicate_of"]]
        cards.append({"demand_id": "S1-" + digest([scope, pid, issue]), "method": "S1",
                      "status": "待补证据" if scope == "current" else "历史或其他市场线索",
                      "scope": scope, "product_id": pid, "issue": issue, "category": category,
                      "source_titles_as_reported": sorted({e["product_title_as_reported"] for e in support if e["product_title_as_reported"]}),
                      "statement": ISSUES[issue]["statement"], "population": None, "scenario": None,
                      "must_conditions": [{"condition": ISSUES[issue]["statement"] + "，需明确可检验目标",
                                           "evidence_ids": [e["evidence_id"] for e in support]}],
                      "preferences": [], "target_measurements": None,
                      "unknown": [ISSUES[issue]["unknown"], "采购数量、目标价格、交付要求", "其他独立使用者的证据"],
                      "hypotheses": [], "support_evidence_ids": [e["evidence_id"] for e in support],
                      "counter_evidence_ids": counter,
                      "counter_limit": "合身正面评价仅为同商品对照；买家和尺码可能不同",
                      "distinct_text_signals": len({e["text_signal_group"] for e in support}),
                      "window": config["window"], "market_basis": support[0]["market_basis"],
                      "manual_review": {"status": "pending", "version": 1},
                      "extraction_method": "finite_rules_v1"})
    return cards
