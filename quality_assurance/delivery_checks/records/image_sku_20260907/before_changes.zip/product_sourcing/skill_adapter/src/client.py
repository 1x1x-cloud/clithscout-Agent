"""ClothScout module; migrated without changing business thresholds."""
import json, os, subprocess, sys
from pathlib import Path
from runtime_support.provider_errors.src.errors import ProviderError

def search_1688(plan, cli_path):
    path = Path(cli_path).resolve()
    if not path.is_file() or path.name != "cli.py":
        raise ProviderError("1688_cli_path_missing")
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1")
    command = [sys.executable, "-B", str(path), "text_search", "--query", plan["query"],
               "--limit", str(plan["limit"]), "--score-level", "high",
               "--purchase-amount", "1", "--tags", "4306497"]
    try:
        result = subprocess.run(command, shell=False, capture_output=True, text=True, encoding="utf-8",
                                env=env, timeout=90, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except subprocess.TimeoutExpired:
        raise ProviderError("1688_cli_timeout_no_retry") from None
    except OSError:
        raise ProviderError("1688_cli_unavailable") from None
    # stderr may include upstream diagnostic material; do not persist it or echo it.
    try:
        payload = json.loads(result.stdout)
    except (json.JSONDecodeError, UnicodeError):
        raise ProviderError("1688_cli_non_json_output") from None
    if result.returncode != 0:
        raise ProviderError("1688_cli_nonzero_exit")
    return payload
