"""ClothScout module; migrated without changing business thresholds."""


def cell(value):
    return str(value if value is not None else "待确认").replace("|", "\\|").replace("\n", " ").replace("\r", " ").replace("<", "&lt;").replace(">", "&gt;")


def render_report(out, manifest, analysis, matches, searches):
    summary = analysis["summary"]
    lines = ["# 服装差评 → 找货对照报告", "",
             "本报告由有限规则引擎自动生成；未覆盖、含糊和矛盾表达进入人工复核。", "",
             f"运行状态：**{manifest['status']}**；开始时间：{manifest['started_at']}。",
             f"观察窗口：{manifest['config']['window']['start']}（含）至 {manifest['config']['window']['end']}（不含）；US 为来源字段所报市场。", "",
             f"原始评价 {summary['raw_rows']} 条；窗口内 {summary['in_window_rows']} 条；窗口外 {summary['outside_window_rows']} 条；时间未知 {summary['unknown_time_rows']} 条。",
             f"当前需求卡 {summary['current_cards']} 张；商品对照 {len(matches)} 条；合格现货测品候选 {sum(m['eligible_for_test'] for m in matches)} 条。",
             f"未覆盖/需人工解释的记录 {summary['unhandled_rows']} 条；重复记录 {summary['duplicate_rows']} 条；ID内容冲突记录 {summary['id_conflict_rows']} 条。", "",
             "上述是返回样本的记录数；没有全星级分母，不计算差评率、独立买家数或市场需求普遍程度。", "",
             "## 当前需求与原文", ""]
    evidence = {e["evidence_id"]: e for e in analysis["evidence"]}
    for card in analysis["demand_cards"]:
        if card["scope"] != "current":
            continue
        lines.extend([f"### {card['demand_id']} · {card['statement']}", "",
                      f"状态：{card['status']}；同商品不同正文信号 {card['distinct_text_signals']} 组（不是独立买家数）。", ""])
        for ref in card["support_evidence_ids"]:
            e = evidence[ref]
            lines.extend([f"> {cell(e['original_text'])}", "",
                          f"证据：{ref}；评价 ID：{cell(e['review_id'])}；来源商品：{cell(e['product_id'])}；时间：{cell(e['published_at'])}。", ""])
        lines.extend(["待确认：" + "；".join(card["unknown"]) + "。", ""])
    if not summary["current_cards"]:
        lines.extend(["本次未生成当前需求卡；不等于市场没有需求。", ""])
    lines.extend(["## 1688 工具原始展示", "", "以下表格为工具返回的原文；价格、卖点和配送标签均未独立核实。", ""])
    for record in searches:
        lines.extend([f"查询用途：{record['plan']['purpose']}。模式：{record['mode']}；来源检查时间：{record['checked_at']}。", ""])
        payload = record.get("payload")
        markdown = payload.get("markdown") if isinstance(payload, dict) else None
        lines.extend([markdown if isinstance(markdown, str) else "没有取得有效工具展示内容。", ""])
        if record.get("error"):
            lines.extend(["查询受限：" + record["error"] + "。不据此认定没有供给。", ""])
    if not searches:
        lines.extend(["本次没有执行商品查询。查询计划见 search_plan.json。", ""])
    lines.extend(["## 逐项商品核对", "",
                  "| 商品 ID / SKU | 满足（仅文字初筛） | 冲突 | 未知 | 结论 |",
                  "|---|---|---|---|---|"])
    for match in matches:
        def fields(status):
            return "；".join(c["condition"] for c in match["conditions"] if c["status"] == status) or "无"
        lines.append(f"| {cell(match['product_id'])} / {cell(match['sku_id'])} | {cell(fields('met'))} | {cell(fields('conflict'))} | {cell(fields('unknown'))} | {match['decision']} |")
    lines.extend(["", "## 下一步复核", "",
                  "- 补所购尺码、目标部位及成衣尺寸；不能从“太大”直接推导 S 码或修身版。",
                  "- 核对替代商品的具体 SKU、规格、实际可采购状态、价格数量条件及交付信息。",
                  "- manual_review.json 保留未覆盖正文、异常、未查询需求及逐商品待办。",
                  "- 历史或其他市场需求保留于 demand_cards.json，不混入当前查询。", "",
                  "程序完成不代表业务候选合格。本版未接入通用语言模型、新 Actor 采集、四平台趋势或采购审批；未验证 CTR、点击下单率及推荐效果。", "",
                  "原始数据见 raw_reviews.json；逐条证据见 evidence.json；全部来源返回见 searches/；执行与校验见 manifest.json、validation.json。", ""])
    if manifest["errors"]:
        lines.extend(["执行问题：" + "；".join(manifest["errors"]), ""])
    (out / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
