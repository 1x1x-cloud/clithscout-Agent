# 服装选品 Agent：新对话接续入口

项目唯一状态入口：[TASK_STATE.md](tiktok_us_data_acceptance_2026-09-05/TASK_STATE.md)。

本文件只维护接续指针。业务规则、已确认配置、证据清单、阻塞与下一步均以该状态文件为准。

新对话需要继续工作时，复制以下提示：

> 请完整读取 C:/Users/86130/Documents/ChatGPT/yuans/tiktok_us_data_acceptance_2026-09-05/TASK_STATE.md，并按其中的接续步骤继续服装选品 Agent 项目。使用具体证据前读取对应引用文件；沿用已确认决策，不重复询问。先说明恢复到的阶段，再推进当前待办。对仍处于熔断状态的操作，先核实恢复条件，不重复失败尝试；不要把历史样本、方案或未执行测试说成当前已验证结果。
