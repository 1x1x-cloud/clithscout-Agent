# 服装差评 Agent · S1 命令行原型

把已有 TikTok Shop 评价导出或 Apify 已完成运行，串联为：**证据 → 有限规则需求卡 → 1688 同品类/款式背景搜索 → 满足/冲突/未知对照 → 人工复核报告**。

业务范围与执行状态以 [TASK_STATE.md](../tiktok_us_data_acceptance_2026-09-05/TASK_STATE.md) 为准。证据和供货规则引用 [V1 方案](../docs/superpowers/specs/2026-09-06-clothing-demand-agent-v1-design.md)，本目录不另设业务阈值。

## 运行

在 `C:\Users\86130\Documents\ChatGPT\yuans` 的 PowerShell 中执行。使用项目现有 `.venv-1688-pilot` 环境，无需重新配置已保存的凭据。

```powershell
# 离线检查：读取现有16条评价、生成需求卡和查询计划，不联网
.\clothing_agent\run.ps1

# 串联实测：读取配置中的既有Apify运行，再执行有上限的1688查询
.\clothing_agent\run.ps1 -Live

# 导入新的本地评价JSON；保持配置里明确的本轮观察窗口
.\clothing_agent\run.ps1 -Reviews 'C:\path\reviews.json'

# 已运行快照重放：用实际输出目录替换路径，不访问网络
.\clothing_agent\run.ps1 -ReplayRun 'C:\path\previous-run'
```

如本机执行策略阻止 `.ps1`，在项目根目录直接用 Python：

```powershell
$env:PYTHONIOENCODING = 'utf-8'
& '.\.venv-1688-pilot\Scripts\python.exe' -B -m clothing_agent --live-read --live-search
```

Python 命令还支持 `--existing-run-id <ID>`（与 `--live-read` 一起用）、`--reviews <JSON>`、`--config <JSON>`、`--replay-run <目录>` 和 `--output-root <目录>`。

**默认没有新采集接口。** `-Live` 只读取已经成功的 Apify 运行，并做配置上限内的商品搜索。它不会启动 Actor、创建定时任务、联系供应商或采购。1688 CLI 自带内部重试；本程序不叠加重试，首次失败就停后续查询。

Apify Token 由 `keyring` 从用户 Windows 凭据管理器读取，服务名 `clothing-agent-apify`，用户名 `APIFY_TOKEN`。必须以保存凭据的用户身份执行；Codex 沙箱身份不同，看不到凭据不等于 Token 丢失。程序仅允许 `api.apify.com` 的限定 GET 路径、拒绝重定向，不打印请求头、Token 或服务错误正文。

## 配置与输出

[current_round.json](config/current_round.json) 是本轮配置快照：市场、服装范围、固定窗口、来源与技术调用上限。程序不自动滚动窗口；每次新窗口应另存配置。下载/查询限制是防止意外扩大调用的技术上限，不是需求成立的样本门槛。1688 的报价数量 1、相关性 high 和品池标签只代表 API 查询输入。

每次在 `runs/UTC时间_随机ID/` 新建独立目录：

| 文件 | 内容 |
|---|---|
| REPORT.md | 当前需求原文、完整1688工具表、逐项核对及后续复核 |
| raw_reviews.json / source.json | 原始字段和来源；本地导入另保存字节一致的 source_reviews.json |
| evidence.json / analysis.json | 逐条证据、时间/市场/重复标记及分析统计 |
| demand_cards.json | 当前和历史/其他市场卡分开；结论引用具体证据 |
| search_plan.json / searches/ | 查询依据、完整工具返回、来源时间与失败情况 |
| product_matches.json | SKU对照、满足/冲突/未知、原报价字段与核验状态 |
| manual_review.json | 未覆盖表达、缺字段、未查询需求和商品核验待办 |
| manifest.json / validation.json | 阶段状态、错误、版本、源码/产物哈希与一致性校验 |

退出码 0 表示本次请求的程序步骤完成；离线模式的搜索阶段明确为 `not_requested`。退出码 1 表示失败或部分完成，已完成的证据和需求卡保留。`-ReplayRun` 检查原产物哈希和查询参数，复用原商品检查时间，不把旧库存/报价标成最新结果。

## 实现范围与限制

- 提取不依赖固定评价 ID。规则支持明确的过长/过短、偏大/偏小、不合身、垂坠、透视、缩水、开线、廉价触感等有限表达；源码 `analysis.py` 是规则定义唯一位置。
- **这不是通用语言模型。** 多语言、讽刺、否定范围、转折以及不在规则内的语义可能漏检；含糊表达保留给人工，不能据此声称没有痛点。真实评论提取准确率尚未验收。
- 同一 ID 重复保留但不增加支持；同一 ID 内容冲突隔离。相同商品/正文只计一组文本信号；不同作者标记或不同评价 ID 不被当作已确认独立买家。作者匿名字段不用于身份推断。
- 品类和款式词来自来源商品标题，作为探索背景，不代表评论者明确要求保留。不会把“太大”改写成“必须 S 码”“必须小个子”或“必须修身”。
- 本版可核对品类和明确的 SKU 部件冲突；评论缺少可检验目标时，具体需求符合保持未知。供货验收未接入，因此不会自动产生“供货已核实”的候选。即使返回正库存数、价格和配送标签，也只保存为供应商所报值。
- 没有完整评论分母，不生成差评率；没有真实商品漏斗，不生成 CTR、点击下单率或爆品概率。
- 未实现：新 Actor 采集、通用模型分析、全部服装细类识别、规格自动核实、供应商确认、四平台趋势、网页工作台、无人值守调度、测品反馈。

## 验证与资料

```powershell
& '.\.venv-1688-pilot\Scripts\python.exe' -B -m unittest discover -s clothing_agent/tests -v
```

tests/ 是明确标记的合成情境，不是市场证据。真实运行证据和最终验证位置在项目唯一状态文件中。记录一致性通过不代表真实供货或推荐效果通过。

API 契约核验（2026-09-06）：[Apify Get run](https://docs.apify.com/api/v2/actor-run-get)、[Get dataset items](https://docs.apify.com/api/v2/dataset-items-get)。1688 实现调用现有本机技能 CLI；参数和展示遵循该技能及其 text_search 参考文档。
