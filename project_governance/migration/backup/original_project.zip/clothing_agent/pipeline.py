"""Single-run orchestration with immutable run folders and partial-failure checkpoints."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from uuid import uuid4

from . import __version__
from .analysis import analyze, validate_config
from .matching import compare_product, plan_searches
from .providers import ProviderError, fetch_reviews, parse_search


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_json(path):
    if path.stat().st_size > 20 * 1024 * 1024:
        raise ValueError("JSON file exceeds 20 MiB technical limit")
    return json.loads(path.read_text(encoding="utf-8-sig"))


def cell(value):
    return str(value if value is not None else "待确认").replace("|", "\\|").replace("\n", " ").replace("\r", " ").replace("<", "&lt;").replace(">", "&gt;")


def validate_run(rows, analysis, matches):
    errors = []
    if len(rows) != len(analysis["evidence"]):
        errors.append("evidence_row_count")
    evidence = {e["evidence_id"]: e for e in analysis["evidence"]}
    for e in evidence.values():
        if e["original_text"] != rows[e["raw_row"] - 1].get("content"):
            errors.append("original_text_changed")
        for extraction in e["extractions"]:
            if extraction["quote"] not in (e["original_text"] or ""):
                errors.append("unsupported_excerpt")
    cards = {c["demand_id"]: c for c in analysis["demand_cards"]}
    for card in cards.values():
        refs = card["support_evidence_ids"] + card["counter_evidence_ids"]
        if not refs or any(ref not in evidence for ref in refs):
            errors.append("invalid_evidence_reference")
        if card["scope"] == "current" and any(evidence[ref]["in_window"] is not True for ref in refs):
            errors.append("historical_evidence_in_current_card")
    for match in matches:
        if match["demand_id"] not in cards:
            errors.append("invalid_demand_reference")
        if match["eligible_for_test"] or match["supply_verified"] or match["verified_stock"] is not None:
            errors.append("unsupported_procurement_approval")
    return {"checked_at": now(), "passed": not errors, "errors": errors,
            "scope": "Record integrity, excerpts, references, time separation and conservative candidate gate; not source truth or extraction accuracy."}


def render_report(out, manifest, analysis, matches, searches):
    summary = analysis["summary"]
    lines = ["# 服装差评 → 找货对照报告", "",
             "本报告由有限规则引擎自动生成；未覆盖、含糊和矛盾表达进入人工复核。", "",
             f"运行状态：**{manifest['status']}**；开始时间：{manifest['started_at']}。",
             f"观察窗口：{manifest['config']['window']['start']}（含）至 {manifest['config']['window']['end']}（不含）；US 为来源字段所报市场。", "",
             f"原始评价 {summary['raw_rows']} 条；窗口内 {summary['in_window_rows']} 条；窗口外 {summary['outside_window_rows']} 条；时间未知 {summary['unknown_time_rows']} 条。",
             f"当前需求卡 {summary['current_cards']} 张；商品对照 {len(matches)} 条；合格现货测品候选 {sum(m['eligible_for_test'] for m in matches)} 条。",
             f"未覆盖/需人工解释的记录 {summary['unhandled_rows']} 条；重复记录 {summary['duplicate_rows']} 条；ID内容冲突记录 {summary['id_conflict_rows']} 条。", "",
             "上述是返回样本的记录数；没有全星级分母，不计算差评率、独立买家数或市场需求普遍程度。", "",
             "## 当前需求与原文", ""]
    evidence = {e["evidence_id"]: e for e in analysis["evidence"]}
    for card in analysis["demand_cards"]:
        if card["scope"] != "current":
            continue
        lines.extend([f"### {card['demand_id']} · {card['statement']}", "",
                      f"状态：{card['status']}；同商品不同正文信号 {card['distinct_text_signals']} 组（不是独立买家数）。", ""])
        for ref in card["support_evidence_ids"]:
            e = evidence[ref]
            lines.extend([f"> {cell(e['original_text'])}", "",
                          f"证据：{ref}；评价 ID：{cell(e['review_id'])}；来源商品：{cell(e['product_id'])}；时间：{cell(e['published_at'])}。", ""])
        lines.extend(["待确认：" + "；".join(card["unknown"]) + "。", ""])
    if not summary["current_cards"]:
        lines.extend(["本次未生成当前需求卡；不等于市场没有需求。", ""])
    lines.extend(["## 1688 工具原始展示", "", "以下表格为工具返回的原文；价格、卖点和配送标签均未独立核实。", ""])
    for record in searches:
        lines.extend([f"查询用途：{record['plan']['purpose']}。模式：{record['mode']}；来源检查时间：{record['checked_at']}。", ""])
        payload = record.get("payload")
        markdown = payload.get("markdown") if isinstance(payload, dict) else None
        lines.extend([markdown if isinstance(markdown, str) else "没有取得有效工具展示内容。", ""])
        if record.get("error"):
            lines.extend(["查询受限：" + record["error"] + "。不据此认定没有供给。", ""])
    if not searches:
        lines.extend(["本次没有执行商品查询。查询计划见 search_plan.json。", ""])
    lines.extend(["## 逐项商品核对", "",
                  "| 商品 ID / SKU | 满足（仅文字初筛） | 冲突 | 未知 | 结论 |",
                  "|---|---|---|---|---|"])
    for match in matches:
        def fields(status):
            return "；".join(c["condition"] for c in match["conditions"] if c["status"] == status) or "无"
        lines.append(f"| {cell(match['product_id'])} / {cell(match['sku_id'])} | {cell(fields('met'))} | {cell(fields('conflict'))} | {cell(fields('unknown'))} | {match['decision']} |")
    lines.extend(["", "## 下一步复核", "",
                  "- 补所购尺码、目标部位及成衣尺寸；不能从“太大”直接推导 S 码或修身版。",
                  "- 核对替代商品的具体 SKU、规格、实际可采购状态、价格数量条件及交付信息。",
                  "- manual_review.json 保留未覆盖正文、异常、未查询需求及逐商品待办。",
                  "- 历史或其他市场需求保留于 demand_cards.json，不混入当前查询。", "",
                  "程序完成不代表业务候选合格。本版未接入通用语言模型、新 Actor 采集、四平台趋势或采购审批；未验证 CTR、点击下单率及推荐效果。", "",
                  "原始数据见 raw_reviews.json；逐条证据见 evidence.json；全部来源返回见 searches/；执行与校验见 manifest.json、validation.json。", ""])
    if manifest["errors"]:
        lines.extend(["执行问题：" + "；".join(manifest["errors"]), ""])
    (out / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")


def run_pipeline(config, output_root, reviews_path=None, run_id=None, search_fn=None,
                 search_mode="none", replay_provenance=None):
    validate_config(config)
    if (reviews_path is None) == (run_id is None):
        raise ValueError("Provide exactly one local review file or existing run ID")
    out = Path(output_root) / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ_") + uuid4().hex[:8])
    out.mkdir(parents=True, exist_ok=False)
    (out / "searches").mkdir()
    manifest = {"version": __version__, "run_id": out.name, "started_at": now(), "status": "running",
                "config": config, "steps": {}, "errors": [], "new_actor_runs_started": 0,
                "supply_absent": False, "search_mode": search_mode,
                "replay_provenance": replay_provenance, "source_code_sha256": {
                    p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob("*.py")}}
    write_json(out / "manifest.json", manifest)
    rows, analysis, matches, searches = [], None, [], []
    try:
        if reviews_path is not None:
            path = Path(reviews_path).resolve()
            rows = load_json(path)
            original_bytes = path.read_bytes()
            (out / "source_reviews.json").write_bytes(original_bytes)
            source = {"source": "local_export", "path": str(path),
                      "sha256": hashlib.sha256(original_bytes).hexdigest()}
        else:
            rows, source = fetch_reviews(run_id, config["limits"]["max_reviews"])
        write_json(out / "raw_reviews.json", rows)
        write_json(out / "source.json", source)
        manifest["steps"]["read"] = "completed"
        write_json(out / "manifest.json", manifest)
        analysis = analyze(rows, config)
        write_json(out / "analysis.json", analysis)
        write_json(out / "evidence.json", analysis["evidence"])
        write_json(out / "demand_cards.json", analysis["demand_cards"])
        plans = plan_searches(analysis["demand_cards"], config)
        write_json(out / "search_plan.json", plans)
        manifest["steps"]["analyze"] = "completed"
        manifest["steps"]["search"] = "not_requested" if search_fn is None else "running"
        write_json(out / "manifest.json", manifest)
        for plan in plans if search_fn is not None else []:
            record = {"plan": plan, "mode": search_mode, "checked_at": now()}
            try:
                response = search_fn(plan)
                # Replay preserves the source time, not the time of the new analysis.
                if search_mode == "replay":
                    record["checked_at"] = response["checked_at"]
                    record["replayed_at"] = now()
                    response = response["payload"]
                record["payload"] = response
                products = parse_search(response)
                for product in products:
                    for card in analysis["demand_cards"]:
                        if card["demand_id"] in plan["demand_ids"]:
                            match = compare_product(card, product)
                            match.update(query_id=plan["query_id"], checked_at=record["checked_at"], source_mode=search_mode)
                            matches.append(match)
            except ProviderError as exc:
                record["error"] = str(exc)
                manifest["errors"].append(str(exc))
            finally:
                searches.append(record)
                write_json(out / "searches" / (plan["query_id"] + ".json"), record)
            if record.get("error"):
                break  # No outer retry; stop all further queries after a provider failure.
        manifest["steps"]["search"] = ("failed" if manifest["errors"] else "completed") if search_fn else "not_requested"
        write_json(out / "product_matches.json", matches)
        searched_ids = {did for s in searches if not s.get("error") for did in s["plan"]["demand_ids"]}
        queue = {"evidence": [{"evidence_id": e["evidence_id"], "flags": e["flags"], "text": e["original_text"]}
                              for e in analysis["evidence"] if e["flags"]],
                 "demands": [{"demand_id": c["demand_id"], "scope": c["scope"], "unknown": c["unknown"],
                              "search_executed": c["demand_id"] in searched_ids,
                              "search_limit": "Historical, unknown category, query cap or unrequested search may defer retrieval"}
                             for c in analysis["demand_cards"]],
                 "products": [{"product_id": m["product_id"], "sku_id": m["sku_id"], "demand_id": m["demand_id"],
                              "decision": m["decision"], "action": m["next_action"]} for m in matches]}
        write_json(out / "manual_review.json", queue)
        validation = validate_run(rows, analysis, matches)
        write_json(out / "validation.json", validation)
        manifest["errors"].extend(validation["errors"])
        manifest["steps"]["compare"] = "completed"
        manifest["counts"] = {**analysis["summary"], "search_calls": len(searches), "product_matches": len(matches),
                              "qualified_candidates": sum(m["eligible_for_test"] for m in matches)}
        manifest["status"] = "partial" if manifest["errors"] else "completed"
    except Exception as exc:
        safe = str(exc) if isinstance(exc, ProviderError) else "pipeline_" + type(exc).__name__
        manifest["errors"].append(safe)
        manifest["status"] = "partial" if analysis else "failed"
    finally:
        manifest["finished_at"] = now()
        try:
            if analysis:
                render_report(out, manifest, analysis, matches, searches)
            else:
                (out / "REPORT.md").write_text("# 本次运行未完成\n\n" + "；".join(manifest["errors"]) + "\n\n查看 manifest.json；不能据此判定没有需求或供给。\n", encoding="utf-8")
        except Exception as exc:
            manifest["errors"].append("report_" + type(exc).__name__)
            manifest["status"] = "partial" if analysis else "failed"
        manifest["artifact_sha256"] = {str(p.relative_to(out)).replace("\\", "/"): hashlib.sha256(p.read_bytes()).hexdigest()
                                       for p in out.rglob("*") if p.is_file() and p.name != "manifest.json"}
        write_json(out / "manifest.json", manifest)
    return out
