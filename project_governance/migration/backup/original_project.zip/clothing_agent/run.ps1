param(
    [switch]$Live,
    [string]$Reviews,
    [string]$ReplayRun
)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$pythonExe = Join-Path $projectRoot '.venv-1688-pilot/Scripts/python.exe'
if (-not (Test-Path -LiteralPath $pythonExe)) { throw 'Project Python environment is missing.' }
if (($Live -and ($Reviews -or $ReplayRun)) -or ($Reviews -and $ReplayRun)) {
    throw 'Choose Live, Reviews, or ReplayRun, not multiple input modes.'
}
$agentArgs = @('-B', '-m', 'clothing_agent')
if ($Live) { $agentArgs += @('--live-read', '--live-search') }
if ($Reviews) { $agentArgs += @('--reviews', $Reviews) }
if ($ReplayRun) { $agentArgs += @('--replay-run', $ReplayRun) }
$env:PYTHONIOENCODING = 'utf-8'
Push-Location -LiteralPath $projectRoot
try { & $pythonExe @agentArgs; $agentExit = $LASTEXITCODE } finally { Pop-Location }
exit $agentExit
