"""Reproducible delivery check against real snapshots; never accesses the network."""
import hashlib
import io
import json
from pathlib import Path
import re
import unittest
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
LIVE = ROOT / "runs/20260906T154237Z_38cd565c"
REPLAY = ROOT / "runs/20260906T154800Z_7affd736"
ORIGINAL = WORKSPACE / "tiktok_us_data_acceptance_2026-09-05/shop_negative_reviews_2026-09-06/user_run_20260906_144758/raw_reviews.json"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    output = ROOT / "verification" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output.mkdir(parents=True, exist_ok=False)
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    tests = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    (output / "tests.txt").write_text(stream.getvalue(), encoding="utf-8")
    errors = []
    if not tests.wasSuccessful():
        errors.append("functional_tests_failed")
    original, live, replay = read(ORIGINAL), read(LIVE / "raw_reviews.json"), read(REPLAY / "raw_reviews.json")
    if original != live or original != replay:
        errors.append("raw_review_field_mismatch")
    for folder in [LIVE, REPLAY]:
        manifest = read(folder / "manifest.json")
        if manifest["status"] != "completed" or not read(folder / "validation.json")["passed"]:
            errors.append("run_or_validation_failed")
        for name, expected in manifest["artifact_sha256"].items():
            if hashlib.sha256((folder / name).read_bytes()).hexdigest() != expected:
                errors.append("artifact_hash_mismatch:" + name)
        cards = read(folder / "demand_cards.json")
        current_ids = {card["demand_id"] for card in cards if card["scope"] == "current"}
        matches = read(folder / "product_matches.json")
        if len(current_ids) != 1 or len(matches) != 3:
            errors.append("unexpected_real_sample_counts")
        if any(m["eligible_for_test"] or m["supply_verified"] or m["demand_id"] not in current_ids for m in matches):
            errors.append("unsupported_candidate_or_historical_match")
        report = (folder / "REPORT.md").read_text(encoding="utf-8")
        for path in (folder / "searches").glob("*.json"):
            if read(path)["payload"]["markdown"] not in report:
                errors.append("provider_markdown_not_preserved")
        for path in folder.rglob("*"):
            if path.is_file() and re.search(r"apify_api_[A-Za-z0-9_-]+", path.read_text(encoding="utf-8")):
                errors.append("credential_pattern_found:" + path.name)
    source = read(LIVE / "source.json")
    if not all(r["method"] == "GET" and r["status"] == 200 for r in source["http_requests"]):
        errors.append("unexpected_live_http_status")
    if source["new_actor_runs_started"] != 0:
        errors.append("unexpected_new_actor_run")
    if read(LIVE / "demand_cards.json") != read(REPLAY / "demand_cards.json"):
        errors.append("current_replay_card_mismatch")
    summary = {"checked_at": datetime.now(timezone.utc).isoformat(), "passed": not errors,
               "functional_tests": tests.testsRun, "test_failures": len(tests.failures), "test_errors": len(tests.errors),
               "live_run": str(LIVE), "replay_run": str(REPLAY), "reviews_all_fields_match": original == live == replay,
               "review_rows": len(original), "live_get_requests": len(source["http_requests"]),
               "live_1688_queries": 1, "returned_products": 3, "qualified_candidates": 0,
               "new_actor_runs_started": source["new_actor_runs_started"],
               "limits": "No source-page, independent semantic accuracy, stock, fulfilment or conversion validation. Final changes tested offline against the live snapshot.",
               "source_code_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob("*.py")},
               "errors": errors}
    (output / "verification.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"output_directory": str(output), **summary}, ensure_ascii=False, indent=2))
    return 0 if summary["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
