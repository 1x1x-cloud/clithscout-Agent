"""Exploratory retrieval and conservative SKU-aware comparisons, not procurement approval."""
import re
from .analysis import digest, garment

CATEGORIES = {"trousers": "长裤", "top": "上衣", "dress": "连衣裙", "skirt": "半身裙", "shorts": "短裤"}


def plan_searches(cards, config):
    plans = []
    keys = sorted({(c["category"], c["product_id"]) for c in cards if c["scope"] == "current" and c["category"] in CATEGORIES})
    for category, product_id in keys:
        relevant = [c for c in cards if c["scope"] == "current" and c["category"] == category and c["product_id"] == product_id]
        if not relevant:
            continue
        titles = " ".join(relevant[0].get("source_titles_as_reported", []))
        translations = [(r"\bstriped?\b", "条纹"), (r"\bhalter\b", "挂脖"),
                        (r"\bknit(?:ted)?\b", "针织"), (r"\bdrawstring\b", "抽绳"), (r"\bwide[- ]leg\b", "阔腿")]
        context_terms = [label for pattern, label in translations if re.search(pattern, titles, re.IGNORECASE)]
        query = " ".join(context_terms + [CATEGORIES[category], "国内现货 提供具体SKU尺码表和成衣尺寸"])
        plans.append({"query_id": "Q-" + digest(query), "query": query,
                      "demand_ids": [c["demand_id"] for c in relevant],
                      "purpose": "同品类探索；缺少目标规格，不声称已解决痛点或同款",
                      "query_basis": "商品标题提供品类/款式背景；不是评论者要求保留这些属性。尺码表是核验资料，不是已确认商品属性",
                      "context_terms_from_title": context_terms,
                      "limit": config["limits"]["products_per_query"],
                      "purchase_amount": 1, "purchase_amount_basis": "CLI报价输入，不是采购决定",
                      "score_level": "high", "tags": "4306497"})
    merged = {}
    for plan in plans:
        if plan["query_id"] in merged:
            merged[plan["query_id"]]["demand_ids"].extend(plan["demand_ids"])
        else:
            merged[plan["query_id"]] = plan
    return list(merged.values())[:config["limits"]["max_queries"]]


def compare_product(card, product):
    title, sku = str(product.get("title") or ""), str(product.get("sku_title") or "")
    title_category, sku_category = garment(title), garment(sku)
    # Explicit single-component SKU outranks a multi-component offer title.
    if sku_category is None and any(word in sku for word in ("单裤", "仅裤", "裤子")) and not any(word in sku for word in ("上衣+", "上衣＋", "套装", "整套")):
        sku_category = "trousers"
    category = sku_category or title_category
    relation = "unknown" if category is None else ("met" if category == card["category"] else "conflict")
    conditions = [
        {"condition": "服装品类与本次线索对应", "status": relation,
         "evidence": {"title_as_reported": title, "sku_title_as_reported": sku},
         "limit": "标题/SKU文字初筛，不代表款式或实物核验"},
        {"condition": card["statement"] + "：替代商品满足明确目标", "status": "unknown",
         "reason": "原评论缺少可检验目标；返回的标题、尺码标签不能证明痛点解决",
         "evidence_ids": card["support_evidence_ids"]},
        {"condition": "具体SKU规格及材质/成衣尺寸", "status": "unknown",
         "reason": "SKU标签不是完整规格或实测"},
        {"condition": "当前可采购状态、价格数量条件、发货地和交付要求", "status": "unknown",
         "reason": "只有搜索返回；未完成V1供货核验"},
    ]
    return {"demand_id": card["demand_id"], "product_id": str(product["product_id"]),
            "sku_id": str(product["sku_id"]) if product.get("sku_id") is not None else None,
            "source_product": product, "conditions": conditions,
            "style_related": relation, "demand_satisfied": "unknown", "supply_verified": False,
            "verified_stock": None, "stock_as_reported": product.get("stock_amount"),
            "stock_limit": "CLI缺失值可能映射为0；包括正数在内均未独立核实",
            "eligible_for_test": False,
            "decision": "排除：品类/SKU冲突" if relation == "conflict" else "待人工核验",
            "next_action": "补原商品所购尺码和目标尺寸；对齐替代商品SKU后核验规格及供货",
            "ctr": None, "click_to_order_rate": None, "breakout_probability": None}
