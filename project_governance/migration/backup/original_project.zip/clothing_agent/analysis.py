"""Finite, conservative text rules. No per-review ID annotations or model calls."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import re


def utc(value):
    if not isinstance(value, str):
        raise ValueError("Timestamp requires a timezone")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("Timestamp requires a timezone")
    return parsed.astimezone(timezone.utc)


def validate_config(config):
    try:
        start, end = utc(config["window"]["start"]), utc(config["window"]["end"])
        if start >= end or config["market"] != "US" or config["scope"] != "clothing":
            raise ValueError("Invalid window or unsupported market/scope")
        for name, maximum in [("max_reviews", 10000), ("max_queries", 20), ("products_per_query", 3)]:
            value = config["limits"][name]
            if type(value) is not int or not 1 <= value <= maximum:
                raise ValueError("Invalid technical limit: " + name)
    except (KeyError, TypeError) as exc:
        raise ValueError("Explicit market, scope, window and limits are required") from exc
    return start, end


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]


def normalized(text):
    return re.sub(r"\s+", " ", text.casefold()).strip()


# Translation labels describe observations, never invent target measurements/materials.
RULES = [
    ("too_long", r"\btoo long\b|\blegs? (?:are|is) (?:way |much )?too long\b|裤腿太长|裤子太长", "评价者认为衣物过长", "目标衣长/裤内长、所购尺码及成衣实测"),
    ("too_short", r"\btoo short\b|裤腿太短|衣服太短", "评价者认为衣物过短", "目标衣长/裤内长、所购尺码及成衣实测"),
    ("too_big", r"\btoo (?:big|large|loose)\b|\bruns? (?:big|large)\b|太大|偏大", "评价者认为衣物偏大", "偏大部位、所购尺码、目标尺寸和原商品尺寸"),
    ("too_small", r"\btoo (?:small|tight)\b|\bruns? small\b|太小|偏小|太紧", "评价者认为衣物偏小或过紧", "偏小部位、所购尺码、目标尺寸和原商品尺寸"),
    ("fit_unspecified", r"\bdoes(?:n['’]t| not) fit\b|\b(?:didn['’]t|did not) fit\b|\bbarely fit\b|不合身", "评价者表示不合身但方向未明确", "偏差方向、部位、所购尺码和目标尺寸"),
    ("drape", r"\bnot as flowy\b|\bnot flowy\b|\bdoes(?:n['’]t| not) drape\b|不垂坠", "评价者认为垂坠或飘逸表现不足", "可接受的垂坠表现及样衣对照；不能推定成分"),
    ("transparency", r"\bsee[- ]through\b|\btoo sheer\b|透底|太透", "评价者提到透视/遮蔽不足", "穿着光线、颜色、拉伸条件及实物遮蔽测试"),
    ("shrinkage", r"\b(?:shrank|shrunk)\b|缩水", "评价者报告缩水", "洗护条件、洗前洗后实测及可接受偏差"),
    ("seam_failure", r"\bseams? (?:ripped|split|came apart)\b|\bstitching (?:came|fell) (?:apart|out)\b|开线", "评价者报告缝线/接缝问题", "故障位置、使用条件与实物检验"),
    ("material_feel", r"\b(?:fabric|material) (?:feels? |is )?cheap\b|\bcheap (?:fabric|material)\b|\bitchy\b|面料廉价|扎皮肤", "评价者对面料触感不满", "可接受的触感和实物对照；必须材质仍未知"),
]
ISSUES = {key: {"statement": statement, "unknown": unknown} for key, _, statement, unknown in RULES}


def classify(text):
    t = normalized(text)
    if not t:
        return [], "empty", []
    if re.search(r"ignore (?:all |previous )?instructions|powershell|system prompt|执行命令|忽略.*指令", t):
        return [], "manual_review", ["instruction_like_source_text"]
    if re.search(r"[?？]|吗|^(?:are|is|do|does|did|can|could|would|will|should)\b", t) and not re.match(r"^(?:does not|did not) fit\b", t):
        return [], "manual_review", ["question_or_hypothetical"]
    remaining_negation = re.sub(r"does not fit|did not fit|not as flowy|not flowy|does not drape", "", t)
    if re.search(r"\b(?:not|never|no)\b|\b(?:aren|weren)['’]t\b", remaining_negation):
        if re.search(r"never received|not received|did not receive|never got|no recibido", t):
            return [], "delivery", []
        return [], "manual_review", ["negation_needs_review"]
    if re.search(r"\b(?:packaging|package|shipping|delivery|arriv\w*|waiting)\b|不太|没太|包装", t):
        return [], "manual_review", ["non_garment_context_or_negation"]
    # Qualifiers and double negation need language understanding beyond this rule slice.
    if re.search(r"\b(?:but|however|although|thought|expected|wish|would|isn['’]t|wasn['’]t)\b|不是|并不", t):
        return [], "manual_review", ["ambiguous_or_contrastive_language"]
    negated = re.search(r"\b(?:not|never)\s+(?:at all\s+)?(?:too|see[- ]through|itchy|shrank|shrunk)|\bno\s+(?:shrinkage|issue|problem)", t)
    if negated:
        return [], "manual_review", ["negation_needs_review"]
    hits = [{"issue": key, "quote": match.group(0), "start": match.start(), "end": match.end()}
            for key, pattern, _, _ in RULES
            if (match := re.search(pattern, t))]
    # Locate an exact excerpt in original text (normalization may change offsets).
    for hit in hits:
        pattern = next(pattern for key, pattern, _, _ in RULES if key == hit["issue"])
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            hit.update(quote=match.group(0), start=match.start(), end=match.end())
        else:
            hit.update(quote=text, start=0, end=len(text))
    if hits:
        return hits, "specific_complaint", []
    if re.search(r"never received|not received|didn['’]t receive|did not receive|not delivered|never got|no recibido|未收到", t):
        return [], "delivery", []
    if re.fullmatch(r"(?:fits? perfectly|true to size)[.!\s]*", t):
        return [], "positive_fit", []
    if re.search(r"\b(?:love|beautiful|great|like it)\b|好看", t):
        return [], "praise_or_unclear", []
    return [], "manual_review", ["uncovered_expression"]


def garment(title):
    if not isinstance(title, str):
        return None
    choices = [("trousers", r"\b(?:pants|trousers|jeans)\b|长裤|牛仔裤|休闲裤"),
               ("top", r"\b(?:top|tops|shirt|blouse|sweater|hoodie)\b|上衣|衬衫|卫衣"),
               ("dress", r"\bdress(?:es)?\b|连衣裙"),
               ("skirt", r"\bskirt\b|半身裙"), ("shorts", r"\bshorts\b|短裤")]
    hits = [category for category, pattern in choices if re.search(pattern, title, re.IGNORECASE)]
    return hits[0] if len(hits) == 1 else None


def analyze(rows, config):
    start, end = validate_config(config)
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError("Review export must be a JSON array of objects")
    if len(rows) > config["limits"]["max_reviews"]:
        raise ValueError("Review file exceeds configured limit")
    signatures = defaultdict(set)
    for row in rows:
        if row.get("reviewId"):
            signatures[str(row["reviewId"])].add(digest({k: row.get(k) for k in
                ("content", "productId", "skuId", "timestamp", "rating", "authorCountry", "productTitle", "productUrl", "status")}))
    evidence, seen_ids = [], {}
    for index, row in enumerate(rows):
        raw_text = row.get("content")
        text = raw_text if isinstance(raw_text, str) else ""
        hits, kind, flags = classify(text)
        eid = "EV-" + digest([row.get("reviewId"), index, row.get("productId"), text])
        try:
            in_window = start <= utc(row.get("timestamp")) < end
        except (ValueError, TypeError):
            in_window = None
            flags.append("missing_or_invalid_timestamp")
        rid = str(row["reviewId"]) if row.get("reviewId") else None
        conflict = bool(rid and len(signatures[rid]) > 1)
        if conflict:
            flags.append("conflicting_review_id")
        if not rid:
            flags.append("missing_review_id")
        if not row.get("productId") or not row.get("productUrl"):
            flags.append("missing_product_context")
        if row.get("status") != "Success":
            flags.append("source_status_not_success")
        if raw_text is not None and not isinstance(raw_text, str):
            flags.append("invalid_content_type")
        duplicate = seen_ids.get(rid) if rid else None
        if rid:
            seen_ids.setdefault(rid, eid)
        evidence.append({"evidence_id": eid, "raw_row": index + 1, "review_id": rid,
                         "product_id": str(row["productId"]) if row.get("productId") else None,
                         "sku_id": str(row["skuId"]) if row.get("skuId") else None,
                         "original_text": raw_text, "source_url": row.get("productUrl"),
                         "product_title_as_reported": row.get("productTitle"),
                         "published_at": row.get("timestamp"), "read_at_as_reported": row.get("scrapedAt"),
                         "market_as_reported": row.get("authorCountry"),
                         "market_basis": "Actor country field; buyer residence not independently verified",
                         "verified_purchase_as_reported": row.get("authorVerified"), "rating": row.get("rating"),
                         "in_window": in_window, "category": garment(row.get("productTitle")),
                         "kind": kind, "extractions": hits, "flags": flags,
                         "duplicate_of": duplicate, "id_conflict": conflict,
                         "text_signal_group": digest([row.get("productId"), normalized(text)]),
                         "independent_buyer_verified": False})
    groups = defaultdict(list)
    for e in evidence:
        if e["duplicate_of"] or e["flags"]:
            continue
        scope = "current" if e["in_window"] and e["market_as_reported"] == config["market"] else "historical_or_other_market"
        for hit in e["extractions"]:
            groups[(scope, e["product_id"], hit["issue"])].append(e)
    cards = []
    for (scope, pid, issue), support in groups.items():
        categories = {e["category"] for e in support}
        category = next(iter(categories)) if len(categories) == 1 else None
        counter = [e["evidence_id"] for e in evidence if e["product_id"] == pid
                   and e["kind"] == "positive_fit" and issue in ("too_long", "too_short", "too_big", "too_small", "fit_unspecified")
                   and e["in_window"] == support[0]["in_window"] and e["market_as_reported"] == config["market"]
                   and not e["flags"] and not e["duplicate_of"]]
        cards.append({"demand_id": "S1-" + digest([scope, pid, issue]), "method": "S1",
                      "status": "待补证据" if scope == "current" else "历史或其他市场线索",
                      "scope": scope, "product_id": pid, "issue": issue, "category": category,
                      "source_titles_as_reported": sorted({e["product_title_as_reported"] for e in support if e["product_title_as_reported"]}),
                      "statement": ISSUES[issue]["statement"], "population": None, "scenario": None,
                      "must_conditions": [{"condition": ISSUES[issue]["statement"] + "，需明确可检验目标",
                                           "evidence_ids": [e["evidence_id"] for e in support]}],
                      "preferences": [], "target_measurements": None,
                      "unknown": [ISSUES[issue]["unknown"], "采购数量、目标价格、交付要求", "其他独立使用者的证据"],
                      "hypotheses": [], "support_evidence_ids": [e["evidence_id"] for e in support],
                      "counter_evidence_ids": counter,
                      "counter_limit": "合身正面评价仅为同商品对照；买家和尺码可能不同",
                      "distinct_text_signals": len({e["text_signal_group"] for e in support}),
                      "window": config["window"], "market_basis": support[0]["market_basis"],
                      "manual_review": {"status": "pending", "version": 1},
                      "extraction_method": "finite_rules_v1"})
    return {"evidence": evidence, "demand_cards": cards,
            "summary": {"raw_rows": len(rows), "in_window_rows": sum(e["in_window"] is True for e in evidence),
                        "outside_window_rows": sum(e["in_window"] is False for e in evidence),
                        "unknown_time_rows": sum(e["in_window"] is None for e in evidence),
                        "duplicate_rows": sum(bool(e["duplicate_of"]) for e in evidence),
                        "id_conflict_rows": sum(e["id_conflict"] for e in evidence),
                        "kinds": dict(Counter(e["kind"] for e in evidence)),
                        "independent_buyers": None, "negative_review_rate": None,
                        "current_cards": sum(c["scope"] == "current" for c in cards),
                        "unhandled_rows": sum(bool(e["flags"]) for e in evidence)}}
