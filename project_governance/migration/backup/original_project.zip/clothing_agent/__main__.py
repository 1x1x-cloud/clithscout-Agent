import argparse
import hashlib
import json
from pathlib import Path
import sys

from .pipeline import load_json, run_pipeline
from .providers import ProviderError, search_1688


def main():
    parser = argparse.ArgumentParser(description="服装差评需求与1688找货对照；只读取已有Apify运行")
    parser.add_argument("--config", default=str(Path(__file__).parent / "config/current_round.json"))
    sources = parser.add_mutually_exclusive_group()
    sources.add_argument("--reviews", type=Path)
    sources.add_argument("--live-read", action="store_true")
    sources.add_argument("--replay-run", type=Path)
    parser.add_argument("--existing-run-id")
    parser.add_argument("--live-search", action="store_true")
    parser.add_argument("--output-root", type=Path, default=Path(__file__).parent / "runs")
    args = parser.parse_args()
    config = load_json(Path(args.config))
    root = Path(__file__).resolve().parent.parent
    reviews = args.reviews or root / config["local_review_file"]
    run_id, search_fn, mode, provenance = None, None, "none", None
    if args.existing_run_id and not args.live_read:
        parser.error("--existing-run-id requires --live-read")
    if args.live_read:
        reviews, run_id = None, args.existing_run_id or config["apify_existing_run_id"]
    if args.replay_run:
        if args.live_search:
            parser.error("Replay cannot start live queries")
        previous = args.replay_run.resolve()
        manifest = load_json(previous / "manifest.json")
        for name, expected in manifest["artifact_sha256"].items():
            file = (previous / name).resolve()
            if previous not in file.parents or hashlib.sha256(file.read_bytes()).hexdigest() != expected:
                raise ProviderError("replay_artifact_integrity_failed")
        config = manifest["config"]
        reviews = previous / "raw_reviews.json"
        mode = "replay"
        provenance = str(previous)
        def search_fn(plan):
            record_path = previous / "searches" / (plan["query_id"] + ".json")
            if not record_path.exists():
                raise ProviderError("replay_query_not_available")
            record = load_json(record_path)
            if record["plan"] != plan or record.get("error"):
                raise ProviderError("replay_query_mismatch_or_previous_failure")
            return record
        if manifest.get("steps", {}).get("search") == "not_requested":
            search_fn = None
    elif args.live_search:
        mode = "live"
        search_fn = lambda plan: search_1688(plan, config["1688_cli"])
    out = run_pipeline(config, args.output_root, reviews_path=reviews, run_id=run_id,
                       search_fn=search_fn, search_mode=mode, replay_provenance=provenance)
    manifest = load_json(out / "manifest.json")
    print(json.dumps({"output_directory": str(out.resolve()), "status": manifest["status"],
                      "counts": manifest.get("counts"), "errors": manifest["errors"]}, ensure_ascii=False, indent=2))
    return 0 if manifest["status"] == "completed" else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ProviderError, ValueError, OSError, KeyError) as exc:
        print(json.dumps({"status": "failed", "error": str(exc) if isinstance(exc, ProviderError) else type(exc).__name__}))
        sys.exit(1)
