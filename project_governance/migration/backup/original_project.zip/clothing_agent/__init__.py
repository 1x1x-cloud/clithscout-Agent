"""Auditable S1 clothing review pipeline, with bounded rule extraction."""

__version__ = "0.1.0"
