"""Bounded read-only providers. Secrets never enter arguments, URLs or output."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request


class ProviderError(Exception):
    """Safe fixed error message, without headers, body or credentials."""


def valid_id(value):
    return isinstance(value, str) and bool(re.fullmatch(r"[A-Za-z0-9]+", value))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class ApifyReader:
    def __init__(self):
        import keyring
        token = keyring.get_password("clothing-agent-apify", "APIFY_TOKEN")
        if not token or any(ord(c) < 33 or ord(c) > 126 for c in token):
            raise ProviderError("apify_credential_unavailable_in_this_windows_identity")
        self._token = token
        self.requests = []
        self._opener = urllib.request.build_opener(NoRedirect())

    def __call__(self, path):
        if not re.fullmatch(r"(?:actor-runs/[A-Za-z0-9]+|datasets/[A-Za-z0-9]+(?:/items\?format=json&offset=\d+&limit=\d+)?)", path):
            raise ProviderError("apify_path_rejected")
        request = urllib.request.Request("https://api.apify.com/v2/" + path, method="GET",
                    headers={"Authorization": "Bearer " + self._token, "Accept": "application/json"})
        record = {"path": path, "method": "GET"}
        self.requests.append(record)
        try:
            with self._opener.open(request, timeout=25) as response:
                body = response.read(20 * 1024 * 1024 + 1)
                record["status"] = response.status
                if len(body) > 20 * 1024 * 1024:
                    raise ProviderError("apify_response_size_limit")
                text = body.decode("utf-8")
                if self._token in text:
                    raise ProviderError("credential_in_response_rejected")
                record["sha256"] = hashlib.sha256(body).hexdigest()
                return json.loads(text)
        except urllib.error.HTTPError as exc:
            record["status"] = exc.code
            raise ProviderError("apify_http_" + str(exc.code)) from None
        except (urllib.error.URLError, TimeoutError, OSError):
            raise ProviderError("apify_network_failed_no_retry") from None
        except (UnicodeError, json.JSONDecodeError):
            raise ProviderError("apify_invalid_json") from None

    def close(self):
        self._token = None


def fetch_reviews(run_id, max_reviews, get=None, page_size=100):
    if not valid_id(run_id) or not 1 <= page_size <= 100 or not 1 <= max_reviews <= 10000:
        raise ProviderError("apify_invalid_run_or_limit")
    owned = get is None
    get = ApifyReader() if owned else get
    try:
        run = get("actor-runs/" + run_id).get("data", {})
        if run.get("id") != run_id or run.get("status") != "SUCCEEDED":
            raise ProviderError("apify_run_not_succeeded")
        dataset_id = run.get("defaultDatasetId")
        if not valid_id(dataset_id):
            raise ProviderError("apify_missing_dataset")
        dataset_path = "datasets/" + dataset_id
        metadata = get(dataset_path).get("data", {})
        total = metadata.get("itemCount")
        if metadata.get("id") != dataset_id or type(total) is not int or total < 0 or total > max_reviews:
            raise ProviderError("apify_dataset_count_invalid_or_over_limit")
        rows = []
        while len(rows) < total:
            limit = min(page_size, total - len(rows))
            query = urllib.parse.urlencode({"format": "json", "offset": len(rows), "limit": limit})
            page = get(dataset_path + "/items?" + query)
            if not isinstance(page, list) or not 1 <= len(page) <= limit:
                raise ProviderError("apify_incomplete_or_invalid_page")
            rows.extend(page)
        after = get(dataset_path).get("data", {})
        if any(metadata.get(key) != after.get(key) for key in ("id", "itemCount", "modifiedAt")):
            raise ProviderError("apify_dataset_changed_during_read")
        return rows, {"source": "apify_existing_run", "run_id": run_id, "dataset_id": dataset_id,
                      "run_status": run["status"], "item_count": total,
                      "dataset_modified_at": metadata.get("modifiedAt"),
                      "http_requests": getattr(get, "requests", []), "new_actor_runs_started": 0}
    finally:
        if owned:
            get.close()


def parse_search(payload):
    if not isinstance(payload, dict) or payload.get("success") is not True:
        raise ProviderError("1688_search_failed")
    inner = payload.get("data", {})
    if isinstance(inner, dict) and "data" in inner:
        inner = inner["data"]
    if not isinstance(inner, dict) or inner.get("success") is not True or not isinstance(inner.get("similar_products"), list):
        raise ProviderError("1688_response_schema_changed")
    if any(not isinstance(p, dict) or not p.get("product_id") for p in inner["similar_products"]):
        raise ProviderError("1688_product_identity_missing")
    return inner["similar_products"]


def search_1688(plan, cli_path):
    path = Path(cli_path).resolve()
    if not path.is_file() or path.name != "cli.py":
        raise ProviderError("1688_cli_path_missing")
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1")
    command = [sys.executable, "-B", str(path), "text_search", "--query", plan["query"],
               "--limit", str(plan["limit"]), "--score-level", "high",
               "--purchase-amount", "1", "--tags", "4306497"]
    try:
        result = subprocess.run(command, shell=False, capture_output=True, text=True, encoding="utf-8",
                                env=env, timeout=90, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except subprocess.TimeoutExpired:
        raise ProviderError("1688_cli_timeout_no_retry") from None
    except OSError:
        raise ProviderError("1688_cli_unavailable") from None
    # stderr may include upstream diagnostic material; do not persist it or echo it.
    try:
        payload = json.loads(result.stdout)
    except (json.JSONDecodeError, UnicodeError):
        raise ProviderError("1688_cli_non_json_output") from None
    if result.returncode != 0:
        raise ProviderError("1688_cli_nonzero_exit")
    return payload
